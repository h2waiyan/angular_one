import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NewformComponent } from './newform/newform.component';
import { ProductlistComponent } from './productlist/productlist.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {
    path : 'home',
    component: ProductlistComponent
  },
  {
    path: 'cart',
    component : ShoppingcartComponent
  },
  {
    path: 'signup',
    component : SignupComponent
  },
  {
    path: 'newform',
    component : NewformComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
